/***************************************************************************
* Program: Overloaded Operators Demo
* Programmer: Daudi Mlengela(dmlengela@cnm.edu)
* Date: November 17th 2022
* Purpose: To create an overloaded operators class
****************************************************************************/
#include"Time.h"
#include<iostream>
#include<string>

using std::cout;
using std::endl;
using std::string;


int main()
{
	cout << "\n Let say your are scheduling your day. ";
	cout << "\n On Tuesday you wake up at 7:45am";

	Time awake(7, 45);
	Time getToClass(9, 30);
	int timeToGetThere = getToClass - awake;

	cout << "\n Time to get ready for class is " << timeToGetThere << " minutes\n";
   // when do you have to get up if you need to be there 15 mins earlier


	int minutes{ 15 };
	Time getUpEarly = awake - minutes;
	cout << "\n The time to get up and be there 15 minutes earlier" << getUpEarly.GetFormattedString()
		<< " minutes";

	cout << "\n I need to organize my appointments for Friday. There are four";

	Time Meeting{15, 0};
	Time Lunch{12, 0};
	Time Dinner{18, 30};
	Time Walk{8,0};
	Time appts[] = { Meeting, Lunch, Dinner, Walk };

	Time temp;
	const int TOTAL{ 4 };
	for (int i = 0; i < TOTAL; i++)
	{
		for (int j = 1; i < TOTAL; j++)
		{
			if (appts[j - 1] > appts[j])
			{
				temp = appts[j];
				appts[j] = appts[j - 1];
				appts[j - 1] = temp;
			}

		}

	}
	 // Show Results
	cout << "\n My Friday Schedule: \n";
	for (int x = 0; x < TOTAL; x++)
	{
		cout << appts[x].GetFormattedString() << endl;

	}
	cout << "\n But I have to walk today.  My car is not running!";
	cout << "\n That will take me twice as long to get to school.";
	cout << "\n I hope I can get there in time if I get up at 6:30am.";


	Time getUp { 6, 30 };
	Time itWillTake{ getUp + timeToGetThere * 2 };
	if (itWillTake < getToClass || itWillTake == getToClass )
	{
		cout << "\n I made it!";

	}
	else
	{
		cout << "\n Whoops! Tardy Again! ";

	}
	cout << "\n I will be there at" << itWillTake.GetFormattedString();
	return 0;
}
