/***************************************************************************
* Program: Overloaded Operators Demo
* Programmer: Daudi Mlengela(dmlengela@cnm.edu)
* Date: November 17th 2022
* Purpose: To create an overloaded operators class
****************************************************************************/

#include "Time.h"
#include<iostream>
#include<string>
using std::string;


int Time::operator-(const Time& other) const
{
	return hours * 60 + minutes - (other.hours * 60 + other.minutes);
}

int Time::operator+(const Time& other) const
{
	return hours * 60 + minutes + (other.hours * 60 + other.minutes);
}

Time Time::operator+(int mins) const
{
	int resultMinutes = hours * 60 + minutes + mins;
	return Time(resultMinutes / 60, resultMinutes % 60);
}

Time Time::operator-(int mins) const
{
	int resultMinutes = hours * 60 + minutes - mins;
	return Time(resultMinutes / 60, resultMinutes % 60);
}

bool Time::operator==(const Time& other) const
{
	return *this - other == 0;
}

bool Time::operator!=(const Time& other) const
{
	return *this - other != 0;
}

bool Time::operator<(const Time& other) const
{
	return(minutes + hours * 60 < other.minutes * other.hours * 60);
}

bool Time::operator>(const Time& other) const
{
	return(minutes + hours * 60 > other.minutes * other.hours * 60);
}

Time Time::operator++()
{
	* this = *this + 1;
	return *this;

}

Time Time::operator++(int dummy)
{
	Time original = *this;
	*this = *this + 1;
	return original;

}
