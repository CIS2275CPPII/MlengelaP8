/***************************************************************************
* Program: Overloaded Operators Demo
* Programmer: Daudi Mlengela(dmlengela@cnm.edu)
* Date: November 17th 2022
* Purpose: To create an overloaded operators class
****************************************************************************/


#ifndef TIME_H
#define TIME_H

#include <string>
using std::string;
class Time
{
private:
	int hours{};
	int minutes{};
public:
	Time() = default;
	Time(int h, int m) : hours{ h }, minutes{ m } {}
	int GetHours()const { return hours; }
	int GetMinutes()const { return minutes;}
	string GetFormattedString() const {
		return std::to_string(hours) + ":"
			+ std::to_string(minutes);}

	//overloaded operators
	int operator-(const Time& other)const;
	int operator+(const Time& other)const;

	// return minutes
	Time operator+(int mins)const;
	Time operator-(int mins)const;

	// return minutesObject
	bool operator == (const Time& other)const;
	bool operator != (const Time& other)const;
	bool operator < (const Time& other)const;
	bool operator > (const Time& other)const;

	Time operator++(); // prefix
	Time operator++(int dummy); // postfix
};
#endif // !TIME_H

